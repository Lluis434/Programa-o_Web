from django import forms
from .models import Evento

class TipoEvento(forms.ModelForm):
    class Meta:
        model = Evento
        fields = ['tipo_evento', 'cidade', 'endereco', 'data', 'horario', 'entrada', 'valor', 'ingressos']

        widgets = {
            'data': forms.DateInput(attrs={'type': 'date'}),
            'horario': forms.TimeInput(attrs={'type': 'time'}),
            'entrada': forms.Select(attrs={'class': 'entrada-select'}),
            'valor': forms.NumberInput(attrs={'class': 'valor-input'}),
            'ingressos': forms.NumberInput(attrs={'class': 'num-input', 'placeholder': 'Quantidade de Ingressos'})
        }

        labels = {
            'tipo_evento': 'Escolha uma opção de evento',
            'cidade': 'Cidade',
            'endereco': 'Endereço', 
            'data': 'Data',
            'horario': 'Horário',
            'entrada': 'Tipo de Entrada',
            'valor': 'Valor da Entrada',
            'ingressos': 'Ingressos',
        }