from django.db import models

# Create your models here.
class Evento(models.Model):
    TIPO_EVENTO_CHOICES = [
        ('aniversario', 'Aniversário'),
        ('show', 'Show Músical'),
        ('balada', 'Balada'),
        ('fempresa', 'Festa da Empresa'),
    ]

    TIPO_ENTRADA_CHOICES = [
        ('gratuita', 'Gratuita'),
        ('paga', 'Paga'),
    ]

    tipo_evento = models.CharField(max_length=20, choices=TIPO_EVENTO_CHOICES)
    cidade = models.CharField(max_length=50, null=False)
    endereco = models.CharField(max_length=100, null=False)
    data = models.DateField(null=False)
    horario = models.TimeField(null=False)
    entrada = models.CharField(max_length=10, choices=TIPO_ENTRADA_CHOICES, null=False)
    valor = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    ingressos = models.PositiveIntegerField(blank=True, null=True)

    