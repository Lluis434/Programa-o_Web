from django.urls import path
from . import views

urlpatterns = [
    path('', views.opc_eventos, name='opc_eventos'),
    path('eventos/', views.listar_eventos, name='listar_eventos'),

]