from django.shortcuts import render, redirect
from .forms import TipoEvento
from .models import Evento

# Create your views here.
def opc_eventos(request):
    if request.method == 'POST':
        form = TipoEvento(request.POST)
        if form.is_valid():
            '''escolhido = form.cleaned_data['tipo_evento']'''
            form.save()
            '''mensagem = f'Evento criado com sucesso!'''
            '''form = TipoEvento()'''
            '''return render(request, 'index.html', {'form': form, 'mensagem': mensagem})'''
            return redirect('listar_eventos')
    else:
        form = TipoEvento()

    return render(request, 'index.html', {'form': form})

def listar_eventos(request):
    eventos = Evento.objects.all()
    return render(request, 'listar_eventos.html', {'eventos': eventos})
