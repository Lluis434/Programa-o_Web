from django.contrib import admin
from .models import Evento

# Register your models here.
@admin.register(Evento)
class EventoAdmin(admin.ModelAdmin):
    list_display = ('tipo_evento', 'cidade', 'endereco', 'data', 'horario', 'entrada', 'valor', 'ingressos')
    list_filter = ('tipo_evento', 'entrada', 'data')
    search_fields = ('cidade', 'endereco')